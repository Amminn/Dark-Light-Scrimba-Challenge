let element = document.querySelector(".button input");

element.addEventListener("change", function() {
    document.body.classList.toggle('active')
})
